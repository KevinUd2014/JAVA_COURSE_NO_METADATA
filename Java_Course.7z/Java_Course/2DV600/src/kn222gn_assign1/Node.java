package kn222gn_assign1;

public class Node {

	public Object object;
	
	public Node nextElement = null;
	
	public Node(Object element) {
		// TODO Auto-generated constructor stub
		object = element;
	}

	public Object getObject() {
		// TODO Auto-generated method stub
		return object;
	}

	public Node getNext() {
		// TODO Auto-generated method stub
		return nextElement;
	}

}
